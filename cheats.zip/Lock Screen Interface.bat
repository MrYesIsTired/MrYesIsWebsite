@echo off
setlocal

:: 1. Open a PowerShell file browser dialog
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $dlg = New-Object System.Windows.Forms.OpenFileDialog; $dlg.Filter = 'Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg'; $dlg.Title = 'Choose Your New Lock Screen'; if ($dlg.ShowDialog() -eq 'OK') { $dlg.FileName }"') do (
    set "ImagePath=%%I"
)

if "%ImagePath%"=="" (
    echo Selection cancelled.
    pause
    goto :eof
)

:: 2. Copy image to Public Pictures so system services can read it
set "SafePath=%PUBLIC%\Pictures\temp_lockscreen.jpg"
copy /y "%ImagePath%" "%SafePath%" >nul

:: 3. Generate a temporary PowerShell script file
set "PSFile=%TEMP%\set_lockscreen_%RANDOM%.ps1"
if exist "%PSFile%" del "%PSFile%"

echo param([string]$Path) >> "%PSFile%"
echo try { >> "%PSFile%"
echo     Add-Type -AssemblyName System.Runtime.WindowsRuntime >> "%PSFile%"
echo     $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] >> "%PSFile%"
echo     $null = [Windows.System.UserProfile.LockScreen, Windows.System.UserProfile, ContentType = WindowsRuntime] >> "%PSFile%"
echo     $ext = [System.WindowsRuntimeSystemExtensions] >> "%PSFile%"
echo     $mGeneric = ($ext.GetMethods() ^| Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0] >> "%PSFile%"
echo     $mAction = ($ext.GetMethods() ^| Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0] >> "%PSFile%"
echo     $op1 = [Windows.Storage.StorageFile]::GetFileFromPathAsync($Path) >> "%PSFile%"
echo     $t1 = $mGeneric.MakeGenericMethod([Windows.Storage.StorageFile]).Invoke($null, @($op1)) >> "%PSFile%"
echo     $t1.Wait() >> "%PSFile%"
echo     $op2 = [Windows.System.UserProfile.LockScreen]::SetImageFileAsync($t1.Result) >> "%PSFile%"
echo     $t2 = $mAction.Invoke($null, @($op2)) >> "%PSFile%"
echo     $t2.Wait() >> "%PSFile%"
echo     Write-Host 'Lock screen changed successfully!' >> "%PSFile%"
echo } catch { >> "%PSFile%"
echo     Write-Host ("FAILED. Error: " + $_.Exception.Message) >> "%PSFile%"
echo } >> "%PSFile%"

echo Applying lock screen...

:: 4. Run the generated script
powershell -NoProfile -ExecutionPolicy Bypass -File "%PSFile%" "%SafePath%"

:: 5. Clean up temporary files
del "%PSFile%" >nul 2>&1
del "%SafePath%" >nul 2>&1

echo.
pause
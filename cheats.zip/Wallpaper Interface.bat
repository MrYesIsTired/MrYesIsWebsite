@echo off
setlocal

:: Open a PowerShell file browser dialog and capture the selected path
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $dlg = New-Object System.Windows.Forms.OpenFileDialog; $dlg.Filter = 'Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All Files (*.*)|*.*'; $dlg.Title = 'Choose Your New Wallpaper'; if ($dlg.ShowDialog() -eq 'OK') { $dlg.FileName }"') do (
    set "ImagePath=%%I"
)

:: Check if the user cancelled or picked an image
if "%ImagePath%"=="" (
    echo Wallpaper selection was cancelled.
    pause
    goto :eof
)

echo Setting wallpaper to: %ImagePath%

:: Apply the wallpaper instantly using the Win32 API
powershell -NoProfile -Command "Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public class Win32 { [DllImport(\"user32.dll\", CharSet = CharSet.Auto)] public static extern int SystemParametersInfo(int uAction, int uParam, string lvParam, int fuWinIni); }'; [Win32]::SystemParametersInfo(0x0014, 0, '%ImagePath%', 0x01 -bor 0x02)"

echo.
echo Wallpaper changed successfully!
pause
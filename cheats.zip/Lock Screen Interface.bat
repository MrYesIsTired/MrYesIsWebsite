@echo off
setlocal

:: Open a PowerShell file browser dialog and capture the selected path
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $dlg = New-Object System.Windows.Forms.OpenFileDialog; $dlg.Filter = 'Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All Files (*.*)|*.*'; $dlg.Title = 'Choose Your New Lock Screen'; if ($dlg.ShowDialog() -eq 'OK') { $dlg.FileName }"') do (
    set "ImagePath=%%I"
)

:: Check if the user cancelled or picked an image
if "%ImagePath%"=="" (
    echo Lock screen selection was cancelled.
    pause
    goto :eof
)

echo Setting lock screen to: %ImagePath%

:: Apply the lock screen using Windows Runtime (WinRT) APIs via PowerShell
powershell -NoProfile -Command "$imgPath = '%ImagePath%'; $code = 'using System; using System.Threading.Tasks; using Windows.System.UserProfile; using Windows.Storage; public class LockScreenHelper { public static void SetImage(string path) { Task.Run(async () => { StorageFile file = await StorageFile.GetFileFromPathAsync(path); await LockScreen.SetImageFileAsync(file); }).Wait(); } }'; Add-Type -TypeDefinition $code -ReferencedAssemblies 'System.Runtime.WindowsRuntime', \"$env:windir\System32\WinMetadata\Windows.Foundation.UniversalApiContract.winmd\"; [LockScreenHelper]::SetImage($imgPath)"

echo.
echo Lock screen changed successfully!
pause